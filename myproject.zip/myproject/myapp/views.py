# myapp/views.py
from django.shortcuts import render
from django.http import HttpResponse
from .models import VehicleFootprint
from django.shortcuts import redirect


def vehicle_footprint_view(request):
    if request.method == 'POST':
        car_miles = float(request.POST.get('car_miles'))
        car_efficiency = float(request.POST.get('car_efficiency'))
        public_transport_miles = float(request.POST.get('public_transport_miles'))
        public_transport_efficiency = float(request.POST.get('public_transport_efficiency'))

        # Create a new VehicleFootprint instance and save it to MongoDB
        footprint = VehicleFootprint(
            car_miles=car_miles,
            car_efficiency=car_efficiency,
            public_transport_miles=public_transport_miles,
            public_transport_efficiency=public_transport_efficiency
        )
        footprint.save()
        re_content="""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carbon Footprint Results</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #eaeaea;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #28a745;
        }
        .results {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-left: 4px solid #28a745;
            border-radius: 5px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Added shadow to results */
        }
        .results h2 {
            margin: 0 0 10px;
            color: #333;
        }
        .results p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Your Carbon Footprint Results</h1>
        <div class="results">
            <h2>Calculated Carbon Emissions:</h2>
            <p id="petrolResult">For Petrol Car: """+str((car_miles/car_efficiency)*2.31)+""" kg CO2</p>
            <p id="dieselResult">For Diesel Car: """+str((car_miles/car_efficiency)*2.68)+""" kg CO2</p>
            <p id="publicTransportResult">For Public Transport: """+str(((public_transport_miles*0.04)+(public_transport_miles*0.015))/2)+""" CO2</p>
        </div>
    </div>
</body>
</html>
"""


        return HttpResponse(re_content)

    return render(request, 'myapp/form.html')
